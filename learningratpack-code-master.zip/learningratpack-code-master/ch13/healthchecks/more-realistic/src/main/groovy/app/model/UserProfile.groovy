package app.model

class UserProfile {
  Long id
  String username
  String jobTitle
  String phoneNumber
}
