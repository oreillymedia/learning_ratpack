package app.model

import groovy.transform.InheritConstructors

@InheritConstructors
class ConnectionError extends RuntimeException {}

