package app.model

import groovy.transform.InheritConstructors

@InheritConstructors
class RemoteServiceError extends RuntimeException {}

