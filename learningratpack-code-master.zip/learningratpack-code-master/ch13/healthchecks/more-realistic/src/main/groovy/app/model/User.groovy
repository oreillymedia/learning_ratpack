package app.model

class User {
  Long id
  String username
  String email
}
