This project doesn't have concrete implementations, but rather is fully demonstrated by its tests. Run `./gradlew test` to see it work

