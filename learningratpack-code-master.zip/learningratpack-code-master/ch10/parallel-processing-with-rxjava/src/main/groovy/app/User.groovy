package app

class User {
  Long id
  String username
  String email
  String password
}
