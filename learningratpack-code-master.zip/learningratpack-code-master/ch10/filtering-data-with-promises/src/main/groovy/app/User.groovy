package app

class User {
  String username
  String email
  String password
}
