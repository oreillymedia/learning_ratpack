package app

class UserProfile {
  String username
  String jobTitle
  String phoneNumber
}
