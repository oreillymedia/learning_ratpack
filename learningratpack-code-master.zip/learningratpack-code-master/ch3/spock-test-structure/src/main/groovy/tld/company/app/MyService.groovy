package tld.company.app

class MyService {

  String doServiceCall() {
    "service was called"
  }

  void shutdown() {
    // stub implementation
  }
}
