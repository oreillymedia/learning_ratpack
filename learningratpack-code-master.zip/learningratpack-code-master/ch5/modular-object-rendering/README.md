Some calls:

```
$ curl localhost:5050/users/danveloper
{"username":"danveloper"}

$ curl localhost:5050/users/danveloper?showAll=true
{"username":"danveloper","email":"danielpwoods@gmail.com"}
```
