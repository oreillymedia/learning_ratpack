The `/etc/dbconfig.yml` file can be found as `etc.dbconfig.yml` here.
