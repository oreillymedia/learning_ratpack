package app

class ApplicationConfig {
  DatabaseConfig database
  LandingPageConfig landing
}
