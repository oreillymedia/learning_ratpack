Run this first:

```
sudo keytool -genkey -alias ratpack -keyalg RSA -keystore /etc/server.jks -keypass changeit -storepass changeit -validity 365 -keysize 2048
```
