package app;

import java.util.List;

public class Photos {
  private List<String> links;

  public List<String> getLinks() {
    return links;
  }

  public void setLinks(List<String> links) {
    this.links = links;
  }
}
