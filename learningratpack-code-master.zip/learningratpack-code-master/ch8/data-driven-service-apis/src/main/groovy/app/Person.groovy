package app

class Person {
  Long id
  String name
}
