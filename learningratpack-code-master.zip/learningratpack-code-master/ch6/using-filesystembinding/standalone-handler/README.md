For example:
`curl -H "Host: www.client1.com" "localhost:5050/?file=foo"`
`curl -H "Host: www.client2.com" "localhost:5050/?file=foo"`
