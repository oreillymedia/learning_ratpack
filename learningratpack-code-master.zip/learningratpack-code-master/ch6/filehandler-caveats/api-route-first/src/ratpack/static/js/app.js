(function() {
  console.log("Welcome to Ratpack!");
})();
